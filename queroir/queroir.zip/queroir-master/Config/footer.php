 <!-- Footer -->
 <footer>
    <div class="row">
        <div class="col-lg-12">
            <center><p>Copyright &copy; QueroIr 2017</p></center>
        </div>
    </div>
</footer>