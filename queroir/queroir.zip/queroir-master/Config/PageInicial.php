 <?php
	include_once("Config/eventos.php");
	include_once("Config/contato.php");
 ?>